<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Welcome to SoftAOX</title>
</head>
<body>
<h1>Welcome to softAOX</h1>
<p>This is Login page</p>
</body>
</html>